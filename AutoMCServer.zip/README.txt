Auto MC Server V0.1 ALPHA

Thank you for using Auto MC Server!
Please place this into the same directory as your server JAR file (likely called server.jar).
Then, run your server JAR file. Once it is finished setting everything up, close it, and run
Auto MC Server!